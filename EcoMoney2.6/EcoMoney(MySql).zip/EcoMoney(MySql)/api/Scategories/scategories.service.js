const pool =require ("../../config/database");
module.exports = 
{   // CreateCategorie
    createS: (data,callBack) => 
    {
                pool.query('insert into scategories (nom, description, montant, id_user) values (?,?,?,?)',[
                    data.nom,
                    data.description,
                    data.montant,
                    data.id_user,
                ],(error,results,fields)=>{
                    if(error){
                        return callBack(error);
                    }
                    return callBack(null,results);
                });
    },
    //GetAllCategories
    getSCategories: callBack => {
                pool.query(' select id, nom, etat, dateD, dateF, montant, id_cat from scategories',
                [],
                (error, results, fields) => {
                    if (error){
                        return callBack(error);
                    }
                    return callBack(null,results);
                });
    },
    //GetCategorieById
    getSCategorieByCategorieId: (id, callBack) => {
        pool.query(' select id, nom, etat, dateD, dateF, montant, id_cat from scategories where id=?',
        [id],
        (error, results, fields) => {
            if (error){
                callBack(error);
            }
            return callBack(null, results[0]);
        });
    },
    // UpdateCategorie
    updateSCategorie: (data,callBack) => 
    {
                pool.query('update scategories set nom=?, etat=?, dateD=?, dateF=?, montant=? where id=?',[
                    data.nom,
                    data.etat,
                    data.dateD,
                    data.dateF,
                    data.montant,
                    data.id
                ],(error,results,fields)=>{
                    if(error){
                        return callBack(error);
                    }
                    return callBack(null,results);
                });
    },
    // DeleteCategorie
    deleteSCategorie: (data,callBack) => 
    {
                pool.query('delete from scategories where id=?',
                    [data.id_cat]
                    ,(error,results,fields)=>{
                    if(error){
                        return callBack(error);
                    }
                    return callBack(null,results);
                });
    }
};