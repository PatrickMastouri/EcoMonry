const{
    createSCategorie,
    getSCategorieByCategorieId,
    getSCategories,
    updateSCategories,
    deleteSCategories
} = require("./scategories.controller");

const router = require("express").Router();
const { checkToken } = require ("../../auth/token_validation");
const { checkAuth } = require("../../auth/authorize")

router.post("/",createSCategorie);
router.get("/",getSCategories);
router.get("/:id",getSCategorieByCategorieId);
router.patch("/",updateSCategories);
router.delete("/",deleteSCategories);
module.exports = router;
