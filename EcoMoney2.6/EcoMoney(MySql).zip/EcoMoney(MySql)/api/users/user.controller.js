const { genSaltSync, hashSync, compareSync } = require("bcrypt");
const {sign} = require("jsonwebtoken");
const sgMail = require ("@sendgrid/mail");

const {
    create,
    getUserByUserId,
    getUsers,
    updateUser,
    deleteUser,
    getUserByUserEmail,
    confirmation,
    changepassword,
    getUserByUserMaill
      } = require("./user.service");


//generate a randome code for forget password
var passcode = "";
function makeForgetPasswordCode(length) {
    var result           = '';
    var characters       = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    var charactersLength = characters.length;
    for ( var i = 0; i < length; i++ ) {
       result += characters.charAt(Math.floor(Math.random() * charactersLength));
    }
    return result;
 }


module.exports = {

    //////////////////////////////////////////////////////Create new user walla nsamiouha Register
    createUser: (req,res)=>{

        const body = req.body;
        const salt = genSaltSync(10);
        body.password = hashSync(body.password, salt);       // crypt the password
        
        create(body,(err, results) => 
        {
            if(err){
                console.log(err);
                return res.status(500).json({
                    succes: 0,
                    message: "Email Or UserName is Used"
                })
        }

        const jsontoken = sign({user: results},process.env.key,{expiresIn: "1h" }); //Create the token
        const id = req.body.mail
        const url = `http://localhost:3000/api/users/confirmation/${jsontoken}/${id}` //Create El url ely bch yactivy bih el compte
        sgMail.setApiKey(process.env.SENDGRID_API_KEY);
        const msg = {
            to: "aziz.arfaoui@esprit.tn",
            from: "aziz99arfaoui@gmail.com",
            subject: "Confirm Email For account",
            text: "Please Click this to verify your account",
            html: url};
        //send the mail
        sgMail.send(msg).then(() => {
                console.log('Message sent')
            }).catch((error) => {
                console.log(error.response.body)
                })
        return res.json({
            success: 1,
            message: "Registred successfully please check your mail to verify youre account",
            token: jsontoken,
            id: results.id });
        });
                    
    },

    //////////////////////////////////////////////////////Get User By user id ely yeteb3ath fel parameters
    getUserByUserId: (req,res) => {
        const id = req.params.id;
        getUserByUserId(id, (err,results)=>{
            if (err){
                console.log(err);
                return ;
            }
            if (!results) {
                return res.json({
                    succes: 0,
                    message: "record not found"
                })
            }
            return res.json({
                succes: 1,
                data: results
            })
        });
    },

    getUserByUserMail: (req,res) => {
        const mail = req.params.mail;
        getUserByUserMaill(mail, (err,results)=>{
            if (err){
                console.log(err);
                return ;
            }
            if (!results) {
                return res.json({
                    succes: 0,
                    message: "record not found"
                })
            }
            return res.json({
                succes: 1,
                data: results
            })
        });
    },

    //////////////////////////////////////////////////////Retrieve all Users
    getUsers: (req,res)=>{
        getUsers((err, results) => {
            if(err){
                console.log(err);
                return;
            }
            return res.json({
                succes: 1,
                data: results
            })
        });
    },

    //////////////////////////////////////////////////////Update User
    updateUsers: (req,res)=>{
        const body = req.body;
        const salt = genSaltSync(10);
        body.password = hashSync(body.password, salt);
        updateUser(body, (err, results) => {
            if(err){
                return res.json({
                    succes: 0,
                    message: err
                });
            }
            if(!results){
                return res.json({
                    succes: 0,
                    message: "Failed to update User"
                });
            }
            return res.json({
                succes: 1,
                message: "Updated Succefully"
            })
        });
    },

    //////////////////////////////////////////////////////Delete User
    deleteUsers: (req,res)=>{
        const data = req.body;
        deleteUser(data,(err, results) => {
            if(err){
                console.log(err);
                return;
            }
            if(!results){
                return res.json({
                    succeded: 0,
                    message: "Record not found"
                })
            }
                return res.json({
                    succeded: 1,
                    message: "deleted succefully"
                })
        });
    },

    //////////////Login/////////////////Bch ya3mel el login lezem nthabtou mel activation mta3 el compte ou na3tiou token 
    login:  (req,res) =>{
        const body = req.body;
        getUserByUserEmail(body.mail, (err,results)=>{                      //nlawjou 3al User bel mail 
            if(err)
            {
                return res.json({
                    success: 0,
                    message: err});
            }
            if(!results)
            {
                return res.json({
                    success: 0,
                    message: "No Account With This Mail"});
            }
        const result = compareSync(body.password, results.password);        //check the password
            if(result)
            {
                if(results.confirmed == 1)                                      //if the account is activated
                {
                    results.password = undefined;                               //Hide the password
                    const jsontoken = sign({user: results},process.env.key,{expiresIn: "1h" });     //create the token
                    return res.json({
                        success: 1,
                        message: "login successfully",
                        token: jsontoken,
                        id: results.id,
                        role: results.role });
                }
                else
                results.password = undefined;                               //Hide the password
                const jsontoken = sign({user: results},process.env.key,{expiresIn: "1h" });     //create the token
                return res.json({
                    success: 1,
                    message: "login successfully Please Activate your account",
                    token: jsontoken,
                    id: results.id,
                    role: results.role });
            }    
            else{
                return res.json({
                    success: 0,
                    message: "Invalide Password" });}
                });
    },

    ///////////////////////////////////////////////////////////////////////Confirm Account ijih el mail fel parameters ylawej bih ou y7ot 1
    confirmations: (req,res) => {
        const id = req.params.id;                       //retrieve the id
        const token = req.params.token;                 //retrieve the token  (n7esha zeyda)
        //n7ot 1 fel table user fel activated bch el compte yet7al
        confirmation(id, token,(err,results)=>{
            if (err){
                return res.json({
                    succes: 0,
                    message: err
                })
            }
            if (!results) {
                return res.json({
                    succes: 0,
                    message: "not confirmed"
                })
            }
            return res.json({
                succes: 1,
                data: results,
                message: "youre account is now activated"
            })
        });
    },
    
    //////////////////////////////////////////////////////////////////////////////Send the code to Reset password(Forget password)
    sendPasswordCode: (req,res) => {
        const mail = req.body.mail;                                             //retrieve the mail
        passcode = makeForgetPasswordCode(5);                                   //Generate the random Code
        getUserByUserEmail(mail, (err,results)=>{                      //nlawjou 3al User bel mail 
            if(err)
            {
                return res.json({
                    success: 0,
                    message: err});
            }
            if(!results)
            {
                return res.json({
                    success: 0,
                    message: "Invalide Email"});
            }
        //Prepare to Send the code to the user email("ne9es nekhou el mail ely teb3ath fel req ou n7otou fy blaset el mail mte3y ely njareb bih")
        sgMail.setApiKey(process.env.SENDGRID_API_KEY); 
        const msg = 
        {   to: "aziz.arfaoui@esprit.tn",
            from: "aziz99arfaoui@gmail.com",
            subject: "Code to Reset your password",
            text: "Please Copy and paste this code to change your password",
            html: passcode };

        //Send the Mail with the Code
        if (sgMail.send(msg)){
            return res.json({
                succes: 1,
                message: "Code sent to your mail"})
        }
        return res.json({
            succes: 0,
            message: "message not sent"})
        });
    },

    //////////////////////////////////////////////////////////////////////////////Verify ely lcode valable ou n7otou el MDP el Jdid
    passwordChange: (req,res)=>{
        const body = req.body;     
        const salt = genSaltSync(10);                          
        body.password = hashSync(body.password, salt);          //crypt the new password
        code = body.code;                                       //get the code
        if(code == passcode)
        {                                   //if code is verified we change the password
        changepassword(body, (err, results) => {
            if(err){
                return res.json({
                    succes: 0,
                    message: err
                });
            }
            if(!results){
                return res.json({
                    succes: 0,
                    message: "Failed to Change password"
                });
            }
            return res.json({
                succes: 1,
                message: "password Changed Succefully"
            })
        });
        }
    else
    return res.json({
        succes: 1,
        message: "Code dosent match"
    })
    },

    /////////////////////////////////////////////////////////Send Confirmation Url
    sendConfirmationUrl: (req,res) => {
        const mail = req.body.mail;                       //retrieve the mail
        const url = `http://localhost:3000/api/users/confirmation/${jsontoken}/${id}` //Create El url ely bch yactivy bih el compte
        sgMail.setApiKey(process.env.SENDGRID_API_KEY);
        const msg = {
            to: "aziz.arfaoui@esprit.tn",
            from: "aziz99arfaoui@gmail.com",
            subject: "Confirm Email For account",
            text: "Please Click this to verify your account",
            html: url};
        //send the mail
        sgMail.send(msg).then(() => {
                console.log('Message sent');
                return res.json({
                    succes: 1,
                    message: "Message sent"
                });
            }).catch((error) => {
                console.log(error.response.body)
                return res.json({
                    succes: 0,
                    message: error.response.body
                });
                })
    }

};
