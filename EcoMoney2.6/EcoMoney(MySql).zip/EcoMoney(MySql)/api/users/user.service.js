const pool = require ("../../config/database");

// JSON encoded date
const toSqlDatetime = (inputDate) => 
{
    const date = new Date(inputDate)
    const dateWithOffest = new Date(date.getTime() - (date.getTimezoneOffset() * 60000))
    return dateWithOffest
        .toISOString()
        .slice(0, 19)
        .replace('T', ' ')
}

module.exports = 
{   // CreateUser
    create: (data,callBack) => 
    {
            fixedtime = toSqlDatetime(new Date(data.daten)) // 2016-06-23 01:54:16
                pool.query('insert into user (id, nom, prenom, daten, username, num, mail, password, adresse, role) values (?,?,?,?,?,?,?,?,?,?)',[
                    data.id,
                    data.nom,
                    data.prenom,
                    fixedtime,
                    data.username,
                    data.num,
                    data.mail,
                    data.password,
                    data.adresse,
                    data.role
                ],(error,results,fields)=>{
                    if(error){
                        return callBack(error);
                    }
                    return callBack(null,results);
                });
            
    },
    //GetAllUsers
    getUsers: callBack => {
                pool.query(' select id,nom,prenom,username,daten,num,mail,password,adresse,role from user',
                [],
                (error, results, fields) => {
                    if (error){
                        return callBack(error);
                    }
                    return callBack(null,results);
                });
    },
    //GetUserById
    getUserByUserId: (id, callBack) => {
        pool.query('select id,nom,prenom,username,daten,num,mail,password,adresse,role from user where id=?',
        [id],
        (error, results, fields) => {
            if (error){
                callBack(error);
            }
            return callBack(null, results[0]);
        });
    },
    getUserByUserMaill: (mail, callBack) => {
        pool.query('select id,nom,prenom,username,daten,num,mail,password,adresse,role,confirmed from user where mail=?',
        [mail],
        (error, results, fields) => {
            if (error){
                callBack(error);
            }
            return callBack(null, results[0]);
        });
    },
    //GetUserByEmail
    getUserByUserEmail: (mail, callBack) => {
        pool.query('select * from user where mail=?',
        [mail],
        (error, results, fields) => {
            if (error){
                return callBack(error);
            }
            return callBack(null, results[0]);
        });
    },
    // UpdateUser
    updateUser: (data,callBack) => 
    {
            fixedtime = toSqlDatetime(new Date(data.daten)) // 2016-06-23 01:54:16

                pool.query('update user set nom=?, prenom=?, daten=?, username=?, num=?, mail=?, password=?, adresse=?, role=? where id=?',[
                    data.nom,
                    data.prenom,
                    fixedtime,
                    data.username,
                    data.num,
                    data.mail,
                    data.password,
                    data.adresse,
                    data.role,
                    data.id,
                ],(error,results,fields)=>{
                    if(error){
                        return callBack(error);
                    }
                    return callBack(null,results);
                });
    },
    // DeleteUser
    deleteUser: (data,callBack) => 
    {
                pool.query('delete from user where id =?',
                    [data.id]
                    ,(error,results,fields)=>{
                    if(error){
                        return callBack(error);
                    }
                    return callBack(null,results);
                });
    },
    // EmailConfirmation
    confirmation: (id,token,callBack) => 
    {
                pool.query('update user set confirmed=1 where mail=?',
                    [id]
                    ,(error,results,fields)=>{
                    if(error){
                        return callBack(error);
                    }
                    return callBack(null,results);
                });
    },
    // EmailConfirmation
    changepassword: (data,callBack) => 
    {
                pool.query('update user set password=? where mail=?',
                    [data.password, data.mail]
                    ,(error,results,fields)=>{
                    if(error){
                        return callBack(error);
                    }
                    return callBack(null,results);
                });
    }
    
};