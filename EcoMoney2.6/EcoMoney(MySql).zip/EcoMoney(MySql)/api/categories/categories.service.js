const pool =require ("../../config/database");
module.exports = 
{   // CreateCategorie
    create: (data,callBack) => 
    {
                pool.query('insert into categories (nom_cat, description, montant, id_user) values (?,?,?,?)',[
                    data.nom_cat,
                    data.description,
                    data.montant,
                    data.id_user,
                ],(error,results,fields)=>{
                    if(error){
                        return callBack(error);
                    }
                    return callBack(null,results);
                });
    },
    //GetAllCategories
    getCategories: callBack => {
                pool.query(' select id_cat, nom_cat, description, montant, id_user from categories',
                [],
                (error, results, fields) => {
                    if (error){
                        return callBack(error);
                    }
                    return callBack(null,results);
                });
    },
    //GetCategorieById
    getCategorieByCategorieId: (id, callBack) => {
        pool.query(' select id_cat, nom_cat, description, montant, id_user from categories where id_cat=?',
        [id],
        (error, results, fields) => {
            if (error){
                callBack(error);
            }
            return callBack(null, results[0]);
        });
    },
    // UpdateCategorie
    updateCategorie: (data,callBack) => 
    {
                pool.query('update categories set nom_cat=?, description=?, montant=?, id_user=? where id_cat=?',[
                    data.nom_cat,
                    data.description,
                    data.montant,
                    data.id_user,
                    data.id_cat
                ],(error,results,fields)=>{
                    if(error){
                        return callBack(error);
                    }
                    return callBack(null,results);
                });
    },
    // DeleteCategorie
    deleteCategorie: (data,callBack) => 
    {
                pool.query('delete from categories where id_cat =?',
                    [data.id_cat]
                    ,(error,results,fields)=>{
                    if(error){
                        return callBack(error);
                    }
                    return callBack(null,results);
                });
    }
};