const {
    create,
    getCategorieByCategorieId,
    getCategories,
    updateCategorie,
    deleteCategorie
      } = require("./categories.service");


module.exports = {
    createCategorie: (req,res) => {
        const body = req.body;
        create(body,(err, results) => {
            if(err){
                console.log(err);
                return res.status(500).json({
                    succes: 0,
                    message: err
                })
            }
            return res.json({
                success: 1,
                message: "Categorie Added" });
        });
    },
    getCategorieByCategorieId: (req,res) => {
        const id = req.params.id;
        getCategorieByCategorieId(id, (err,results)=>{
            if (err){
                console.log(err);
                return ;
            }
            if (!results) {
                return res.json({
                    succes: 0,
                    message: "Categorie not found"
                })
            }
            return res.json({
                succes: 1,
                data: results
            })
        });
    },
    getCategories: (req,res)=>{
        getCategories((err, results) => {
            if(err){
                console.log(err);
                return;
            }
            return res.json({
                succes: 1,
                data: results
            })
        });
    },
    updateCategories: (req,res)=>{
        const body = req.body;
        updateCategorie(body, (err, results) => {
            if(err){
                console.log(err);
                return false;
            }
            if(!results){
                return res.json({
                    succes: 0,
                    message: "Failed to update Categorie"
                });
            }
            return res.json({
                succes: 1,
                MESSAGE: "Categorie Updated Succefully"
            })
        });
    },
    deleteCategories: (req,res)=>{
        const data = req.body;
        deleteCategorie(data,(err, results) => {
            if(err){
                console.log(err);
                return;
            }
            if(!results){
                return res.json({
                    succeded: 0,
                    message: "Categorie not found"
                })
            }
            return res.json({
                succeded: 1,
                message: "Categorie deleted succefully"
            })
        });
    }

};
