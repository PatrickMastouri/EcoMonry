const{
    createCategorie,
    getCategorieByCategorieId,
    getCategories,
    updateCategories,
    deleteCategories
} = require("./categories.controller");

const router = require("express").Router();
const { checkToken } = require ("../../auth/token_validation");
const { checkAuth } = require("../../auth/authorize")

router.post("/",createCategorie);
router.get("/",getCategories);
router.get("/:id",getCategorieByCategorieId);
router.patch("/",updateCategories);
router.delete("/",deleteCategories);
module.exports = router;
