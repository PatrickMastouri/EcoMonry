const pool =require ("../../config/database");
module.exports = 
{   // CreateCategorie
    createRec: (data,callBack) => 
    {
                pool.query('insert into reclamation (subject, message, id_user) values (?,?,?)',[
                    data.subject,
                    data.message,
                    data.id_user
                ],(error,results,fields)=>{
                    if(error){
                        return callBack(error);
                    }
                    return callBack(null,results);
                });
    },
    //GetAllCategories
    getReclamation: callBack => {
                pool.query(' select id, subject, message, id_user from reclamation',
                [],
                (error, results, fields) => {
                    if (error){
                        return callBack(error);
                    }
                    return callBack(null,results);
                });
    },
    //GetCategorieById
    getReclamationsByReclamation: (id, callBack) => {
        pool.query(' select id, subject, message, id_user from reclamation where id=?',
        [id],
        (error, results, fields) => {
            if (error){
                callBack(error);
            }
            return callBack(null, results[0]);
        });
    },
    // UpdateCategorie
    updateReclamation: (data,callBack) => 
    {
                pool.query('update reclamation set subject=?, message=?, id_user=? where id=?',[
                    data.subject,
                    data.message,
                    data.id_user,
                    data.id
                ],(error,results,fields)=>{
                    if(error){
                        return callBack(error);
                    }
                    return callBack(null,results);
                });
    },
    // DeleteCategorie
    deleteReclamation: (data,callBack) => 
    {
                pool.query('delete from reclamation where id=?',
                    [data.id]
                    ,(error,results,fields)=>{
                    if(error){
                        return callBack(error);
                    }
                    return callBack(null,results);
                });
    }
};