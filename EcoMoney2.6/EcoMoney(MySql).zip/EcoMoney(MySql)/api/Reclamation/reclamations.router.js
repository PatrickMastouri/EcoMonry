const{
    createReclamation,
    getReclamationByReclamationId,
    getReclamation,
    updateReclamation,
    deleteReclamation
} = require("./reclamations.controller");

const router = require("express").Router();
const { checkToken } = require ("../../auth/token_validation");
const { checkAuth } = require("../../auth/authorize")

router.post("/",createReclamation);
router.get("/",getReclamation);
router.get("/:id",getReclamationByReclamationId);
router.patch("/",updateReclamation);
router.delete("/",deleteReclamation);
module.exports = router;
