

import Foundation
import SwiftKeychainWrapper
import Alamofire

struct User: Decodable {

    let nom: String?
    let prenom: String?
    let username: String?
    let adresse: String?
    let numero: String?
    let password: String?
    let date: String?
    let mail: String?
}

//See If the user have an activated account
func RetrieveUserActivationStat(completion: @escaping ([String:Any]?) -> Void){
    // get UserMail and Token
    let retrievedMail: String? = KeychainWrapper.standard.string(forKey: "mailUser")
    let retrievedToken: String? = KeychainWrapper.standard.string(forKey: "accesstoken")
    // Send The Token With The URL
    let headers: HTTPHeaders = [.authorization(bearerToken: retrievedToken!)]
    // The Url
    var url:String = "http://localhost:3000/api/users/mail/"
    url += retrievedMail!
    // Send The Call Back Function
    AF.request(url, method: .get, parameters: nil, encoding: JSONEncoding.default, headers: headers).validate(statusCode: 200 ..< 299).responseJSON { AFdata in
        do {
            guard let jsonObject = try JSONSerialization.jsonObject(with: AFdata.data!) as? [String: Any] else {
                print("Error: Cannot convert data to JSON object")
                return
            }
            // Send The Response Out
            if let response = jsonObject["data"] as! [String : Any]? {
                completion(response)
                let _: Bool = KeychainWrapper.standard.set(response["id"] as! Int, forKey: "id")
                let retrievedId: Int? = KeychainWrapper.standard.integer(forKey: "id")
                print(retrievedId!)
            }
        } catch {
            print("Error: Trying to convert JSON data to string")
            return
        }
    }.resume()
}
