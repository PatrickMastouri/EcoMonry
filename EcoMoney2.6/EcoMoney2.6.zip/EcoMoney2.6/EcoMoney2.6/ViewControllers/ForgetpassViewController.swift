//
//  ForgetpassViewController.swift
//  EcoMoney2.6
//
//  Created by Aziz Arfaoui on 18/12/2020.
//

import UIKit
import SwiftKeychainWrapper
import Alamofire
class ForgetpassViewController: UIViewController {
    
    @IBOutlet weak var error: UILabel!
    @IBOutlet weak var emailField: UITextField!
    @IBOutlet weak var passwordField: UITextField!
    @IBOutlet weak var codeField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    

    @IBAction func OnResetPassClicked(_ sender: Any) {
        // getData
        let mail: String = emailField.text ?? ""
        let password: String = passwordField.text ?? ""
        let code: String = codeField.text ?? ""

        
        //declare parameter as a dictionary which contains string as key and value combination. considering inputs are valid
        let parameters = [ "mail":mail as Any, "password":password, "code":code] as [String : Any]
        if(CheckForm()){
        AF.request("http://localhost:3000/api/users/forgetpasswordchange/", method: .patch, parameters: parameters, encoding: JSONEncoding.default, headers: nil).validate(statusCode: 200 ..< 299).responseJSON { AFdata in
            do {
                guard let jsonObject = try JSONSerialization.jsonObject(with: AFdata.data!) as? [String: Any] else {
                    print("Error: Cannot convert data to JSON object")
                    return
                }
                print(jsonObject)
                
                DispatchQueue.main.async{
                    self.error.text = jsonObject["message"] as? String ?? "ma3malch update password"
                    if (jsonObject["message"] as! String == "Invalide Email"){
                        self.error.text = jsonObject["message"] as? String ?? "ma3malch update password"
                        self.emailField.layer.borderWidth = 2
                        self.emailField.layer.borderColor = #colorLiteral(red: 0.9254902005, green: 0.2352941185, blue: 0.1019607857, alpha: 1)
                        self.emailField.becomeFirstResponder()
                    }
                    if(jsonObject["message"] as! String == "Code dosent match"){
                        self.error.text = jsonObject["message"] as? String ?? "ma3malch update password"
                        self.codeField.layer.borderWidth = 2
                        self.codeField.layer.borderColor = #colorLiteral(red: 0.9254902005, green: 0.2352941185, blue: 0.1019607857, alpha: 1)
                        self.codeField.becomeFirstResponder()
                    }
                }
            } catch {
                print("Error: Trying to convert JSON data to string")
                return
            }
            
            
        }
        }
    }

    @IBAction func ResendCode(_ sender: Any) {
    }
    
    
    func CheckForm() -> Bool{
        
        var B:Bool = true
        let mail: String = emailField.text ?? ""
        let passwordd: String = passwordField.text ?? ""

        if ((passwordd == "") || (passwordd.count < 2) || (passwordd.count > 10))
          {
            DispatchQueue.main.async{
            self.error.isHidden = false
            self.error.text = "Password Required"
            self.passwordField.layer.borderWidth = 2
            self.passwordField.layer.borderColor = #colorLiteral(red: 0.9254902005, green: 0.2352941185, blue: 0.1019607857, alpha: 1)
            self.passwordField.becomeFirstResponder()}
            B = false
        }else
        {
            DispatchQueue.main.async{
            self.passwordField.layer.borderWidth = 0
            self.passwordField.layer.borderColor = #colorLiteral(red: 0.4666666687, green: 0.7647058964, blue: 0.2666666806, alpha: 1)
            self.passwordField.becomeFirstResponder()}
        }
        if ((mail == "") || (mail.count > 40) || !(isValidEmail(mail)))
          {
            DispatchQueue.main.async{
            self.error.isHidden = false
            self.error.text = "Mail Not Valid"
            self.emailField.layer.borderWidth = 2
            self.emailField.layer.borderColor = #colorLiteral(red: 0.9254902005, green: 0.2352941185, blue: 0.1019607857, alpha: 1)
            self.emailField.becomeFirstResponder()}
            B = false
        }else
        {
            DispatchQueue.main.async{
            self.emailField.layer.borderWidth = 0
            self.emailField.layer.borderColor = #colorLiteral(red: 0.4666666687, green: 0.7647058964, blue: 0.2666666806, alpha: 1)
            self.emailField.becomeFirstResponder()}
        }
        return B

    }
    func isValidEmail(_ email: String) -> Bool {
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"

        let emailPred = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        return emailPred.evaluate(with: email)
    }
}
