//
//  LoginViewController.swift
//  EcoMoney2.6
//
//  Created by Aziz Arfaoui on 18/12/2020.
//

import UIKit
import SwiftKeychainWrapper
import Alamofire

class LoginViewController: UIViewController {
    
    //IBOUtlettes
    @IBOutlet weak var email: UITextField!
    @IBOutlet weak var password: UITextField!
    @IBOutlet weak var erreur: UILabel!
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    

    @IBAction func OnLoginTapped(_ sender: Any) {
        print("Login Tapped")
        let mail: String = email.text ?? ""
        let passwordd: String = password.text ?? ""
        let parameters = ["mail":mail as Any, "password":passwordd] as [String : Any]
        if(CheckForm()){
        AF.request("http://localhost:3000/api/users/login", method: .post, parameters: parameters, encoding: JSONEncoding.default, headers: nil).validate(statusCode: 200 ..< 299).responseJSON { AFdata in
            do {
                guard let jsonObject = try JSONSerialization.jsonObject(with: AFdata.data!) as? [String: Any] else {
                    print("Error: Cannot convert data to JSON object")
                    return
                }
            print(jsonObject)
                let id:Int = jsonObject["id"] as? Int ?? 0
                let idu = String(id)
                let accesstoken:String = jsonObject["token"] as? String ?? "token NotFound"
                let role:String = jsonObject["role"] as? String ?? "role NotFound"
                let _: Bool = KeychainWrapper.standard.set(accesstoken, forKey: "accesstoken")
                let _: Bool = KeychainWrapper.standard.set(idu , forKey: "id")
                let _: Bool = KeychainWrapper.standard.set(mail , forKey: "mailUser")
            DispatchQueue.main.async{
                self.erreur.isHidden = false
                self.erreur.text = jsonObject["message"] as? String ?? "NotFound"}
            if (!(accesstoken == "token NotFound")){
                self.erreur.textColor = UIColor.blue
                DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                    if(role == "admin")
                    {
                        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
                        let aNavViewController = storyBoard.instantiateViewController(withIdentifier: "AdminNav") as! AdminNavViewController
                        self.present(aNavViewController, animated: true, completion: nil)
                        return
                    }
                    else{
                       let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
                       let NavViewController = storyBoard.instantiateViewController(withIdentifier: "Nav") as! NavViewController
                       self.present(NavViewController, animated: true, completion: nil)
                    }
                }
            }}catch {
                print("Error: Trying to convert JSON data to string")
                return}
            }
        }
    }
    
    @IBAction func OnForgetpasswordTapped(_ sender: Any) {
        print("Forget Password Tapped")
        
        if(CheckMail()){
            let mail: String = email.text ?? ""
            let parameters = ["mail":mail as Any] as [String : Any]
            AF.request("http://localhost:3000/api/users/forgetpasswordconfirmation/", method: .post, parameters: parameters, encoding: JSONEncoding.default, headers: nil).validate(statusCode: 200 ..< 299).responseJSON { AFdata in
                do {
                    guard let jsonObject = try JSONSerialization.jsonObject(with: AFdata.data!) as? [String: Any] else {
                        print("Error: Cannot convert data to JSON object")
                        return
                    }
                    print(jsonObject)
                    if(jsonObject["message"] as! String == "Invalide Email"){
                        self.erreur.isHidden = false
                        self.erreur.text = jsonObject["message"] as? String ?? "ma3malch update password"
                        self.email.layer.borderWidth = 2
                        self.email.layer.borderColor = #colorLiteral(red: 0.9254902005, green: 0.2352941185, blue: 0.1019607857, alpha: 1)
                        self.email.becomeFirstResponder()
                    }
                    else{
                        self.erreur.isHidden = false
                        self.erreur.text = jsonObject["message"] as? String ?? "ma3malch update password"
                        self.erreur.textColor = UIColor.blue
                        DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                        let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
                        let aNavViewController = storyBoard.instantiateViewController(withIdentifier: "ForgetPass") as! ForgetpassViewController
                        self.present(aNavViewController, animated: true, completion: nil)
                        return
                        }
                    }
                    
                } catch {
                    print("Error: Trying to convert JSON data to string")
                    return
                }
            }
        }
    }
    
    
    func CheckForm() -> Bool{
        
        var B:Bool = true
        let mail: String = email.text ?? ""
        let passwordd: String = password.text ?? ""

        if ((passwordd == "") || (passwordd.count < 2) || (passwordd.count > 10))
          {
            DispatchQueue.main.async{
            self.erreur.isHidden = false
            self.erreur.text = "Password Required"
            self.password.layer.borderWidth = 2
            self.password.layer.borderColor = #colorLiteral(red: 0.9254902005, green: 0.2352941185, blue: 0.1019607857, alpha: 1)
            self.password.becomeFirstResponder()}
            B = false
        }else
        {
            DispatchQueue.main.async{
            self.password.layer.borderWidth = 0
            self.password.layer.borderColor = #colorLiteral(red: 0.4666666687, green: 0.7647058964, blue: 0.2666666806, alpha: 1)
            self.password.becomeFirstResponder()}
        }
        if ((mail == "") || (mail.count > 40) || !(isValidEmail(mail)))
          {
            DispatchQueue.main.async{
            self.erreur.isHidden = false
            self.erreur.text = "Mail Not Valid"
            self.email.layer.borderWidth = 2
            self.email.layer.borderColor = #colorLiteral(red: 0.9254902005, green: 0.2352941185, blue: 0.1019607857, alpha: 1)
            self.email.becomeFirstResponder()}
            B = false
        }else
        {
            DispatchQueue.main.async{
            self.email.layer.borderWidth = 0
            self.email.layer.borderColor = #colorLiteral(red: 0.4666666687, green: 0.7647058964, blue: 0.2666666806, alpha: 1)
            self.email.becomeFirstResponder()}
        }
        return B

    }
    func CheckMail() -> Bool{
        
        var B:Bool = true
        let mail: String = email.text ?? ""

        if ((mail == "") || (mail.count > 40) || !(isValidEmail(mail)))
          {
            DispatchQueue.main.async{
            self.erreur.isHidden = false
            self.erreur.text = "Mail Not Valid"
            self.email.layer.borderWidth = 2
            self.email.layer.borderColor = #colorLiteral(red: 0.9254902005, green: 0.2352941185, blue: 0.1019607857, alpha: 1)
            self.email.becomeFirstResponder()}
            B = false
        }else
        {
            DispatchQueue.main.async{
            self.email.layer.borderWidth = 0
            self.email.layer.borderColor = #colorLiteral(red: 0.4666666687, green: 0.7647058964, blue: 0.2666666806, alpha: 1)
            self.email.becomeFirstResponder()}
        }
        return B

    }
    func isValidEmail(_ email: String) -> Bool {
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"

        let emailPred = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        return emailPred.evaluate(with: email)
    }
}
