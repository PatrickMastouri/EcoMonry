const { verify } = require("jsonwebtoken");
const atob = require('atob');


function parseJwt(token) {
    var base64Url = token.split('.')[1];
    var base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
    var jsonPayload = decodeURIComponent(atob(base64).split('').map(function(c) {
        return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
    }).join(''));

    return JSON.parse(jsonPayload);
};


module.exports = {
    checkAuth: (req, res, next) =>{
        let token = req.get("authorization");
        if(token){
            token = token.slice(7);
            verify(token, process.env.key, (err,decode)=>{
                if(err){
                    res.json({
                        success: 0,
                        message: "You Have InvalidToken......"
                    })
                }else{
                    if (!(parseJwt(token).user.role == "Admin")) {
                        // user's role is not authorized
                        return res.status(401).json({ message: 'Unauthorized' });
                    }
                    // authentication and authorization successful
                    next();
                }
            });
        }else{
            res.json({
                succes: 0,
                message: "You Dont Have a Token....."
            });
        }
    }
};
