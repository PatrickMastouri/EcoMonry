const{
    createSCategorie,
    getSCategorieByCategorieId,
    getSCategories,
    updateSCategories,
    deleteSCategories,
    getmontantofscs,
    getSScategorieById,
    updateCategoriesMontantAdd,
    updateCategoriesMontantRemove
} = require("./scategories.controller");

const router = require("express").Router();
const { checkToken } = require ("../../auth/token_validation");
const { checkAuth } = require("../../auth/authorize")

router.post("/:id",createSCategorie);
router.get("/montantofscs/:id",getmontantofscs);
router.get("/",getSCategories);
router.get("/:id",getSCategorieByCategorieId);
router.patch("/",updateSCategories);
router.delete("/",deleteSCategories);
router.get("/sc/:id",getSScategorieById);
router.patch("/catM/",updateCategoriesMontantAdd);
router.patch("/catMR/",updateCategoriesMontantRemove);

module.exports = router;
