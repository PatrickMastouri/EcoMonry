const pool =require ("../../config/database");
module.exports = 
{   // CreateCategorie
    createS: (id_cat,data,callBack) => 
    {
                pool.query('insert into scategories (nom, montant, dateF, id_cat) values (?,?,?,?)',[
                    data.nom,
                    data.montant,
                    data.dateF,
                    id_cat,
                ],(error,results,fields)=>{
                    if(error){
                        return callBack(error);
                    }
                    return callBack(null,results);
                });
    },
    //GetAllCategories
    getSCategories: callBack => {
                pool.query(' select id, nom, etat, dateD, dateF, montant, id_cat from scategories',
                [],
                (error, results, fields) => {
                    if (error){
                        return callBack(error);
                    }
                    return callBack(null,results);
                });
    },
    //GetCategorieById
    getSCategorieByCategorieId: (id, callBack) => {
        pool.query(' select id, nom, etat, dateD, dateF, montant, id_cat from scategories where id_cat=?',
        [id],
        (error, results, fields) => {
            if (error){
                callBack(error);
            }
            return callBack(null, results);
        });
    },
    // UpdateCategorie
    updateSCategorie: (data,callBack) => 
    {
                pool.query('update scategories set nom=?, etat=?, dateD=?, dateF=?, montant=? where id=?',[
                    data.nom,
                    data.etat,
                    data.dateD,
                    data.dateF,
                    data.montant,
                    data.id
                ],(error,results,fields)=>{
                    if(error){
                        return callBack(error);
                    }
                    return callBack(null,results);
                });
    },
    // DeleteCategorie
    deleteSCategorie: (data,callBack) => 
    {
                pool.query('delete from scategories where id=?',
                    [data.id]
                    ,(error,results,fields)=>{
                    if(error){
                        return callBack(error);
                    }
                    return callBack(null,results);
                });
    },
    //GetCategorieById
    getmontantofsc: (id, callBack) => {
        pool.query('SELECT SUM(montant) from scategories where id_cat = ?',
        [id],
        (error, results, fields) => {
            if (error){
                callBack(error);
            }
            return callBack(null, results);
        });
    },
    //GetCategorieById
    getSCategorieById: (id, callBack) => {
        pool.query('select id, nom, etat, dateD, dateF, montant, id_cat from scategories where id=?',
        [id],
        (error, results, fields) => {
            if (error){
                callBack(error);
            }
            return callBack(null, results[0]);
        });
    },
    addMontantToCategorie: (data,callBack) => 
    {
                pool.query('update categories set montant = montant + ? where id_cat=? ',[
                    data.montant,
                    data.id,
                ],(error,results,fields)=>{
                    if(error){
                        return callBack(error);
                    }
                    return callBack(null,results);
                });
    },
    RemoveMontantFromCategorie: (data,callBack) => 
    {
                pool.query('update categories set montant = montant - ? where id_cat=?',[
                    data.montant,
                    data.id,
                ],(error,results,fields)=>{
                    if(error){
                        return callBack(error);
                    }
                    return callBack(null,results);
                });
    }
};