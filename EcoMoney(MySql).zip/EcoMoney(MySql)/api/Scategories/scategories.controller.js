const {
    createS,
    getSCategorieByCategorieId,
    getSCategories,
    updateSCategorie,
    deleteSCategorie,
    getmontantofsc,
    getSCategorieById,
    addMontantToCategorie,
    RemoveMontantFromCategorie,
      } = require("./scategories.service");


module.exports = {
    createSCategorie: (req,res) => {
        const body = req.body;
        const id_cat = req.params.id
        createS(id_cat,body,(err, results) => {
            if(err){
                console.log(err);
                return res.status(500).json({
                    succes: 0,
                    message: err
                })
            }
            return res.json({
                success: 1,
                message: "Sous Categorie Added Successfully" });
        });
    },
    getSCategorieByCategorieId: (req,res) => {
        const id = req.params.id;
        getSCategorieByCategorieId(id, (err,results)=>{
            if (err){
                console.log(err);
                return ;
            }
            if (!results) {
                return res.json({
                    succes: 0,
                    message: "Categorie not found"
                })
            }
            return res.json({
                succes: 1,
                data: results
            })
        });
    },
    getSCategories: (req,res)=>{
        getSCategories((err, results) => {
            if(err){
                console.log(err);
                return;
            }
            return res.json({
                succes: 1,
                data: results
            })
        });
    },
    updateSCategories: (req,res)=>{
        const body = req.body;
        updateSCategorie(body, (err, results) => {
            if(err){
                console.log(err);
                return false;
            }
            if(!results){
                return res.json({
                    succes: 0,
                    message: "Failed to update Categorie"
                });
            }
            return res.json({
                succes: 1,
                MESSAGE: "Categorie Updated Succefully"
            })
        });
    },
    deleteSCategories: (req,res)=>{
        const data = req.body;
        deleteSCategorie(data,(err, results) => {
            if(err){
                console.log(err);
                return;
            }
            if(!results){
                return res.json({
                    succeded: 0,
                    message: "SCategorie not found"
                })
            }
            return res.json({
                succeded: 1,
                message: "SCategorie deleted succefully"
            })
        });
    },
    getmontantofscs: (req,res) => {
        const id = req.params.id;
        getmontantofsc(id, (err,results)=>{
            if (err){
                console.log(err);
                return ;
            }
            if (!results) {
                return res.json({
                    succes: 0,
                    message: "Categorie not found"
                })
            }
            return res.json({
                succes: 1,
                data: results
            })
        });
    },
    getSScategorieById: (req,res) => {
        const id = req.params.id;
        getSCategorieById(id, (err,results)=>{
            if (err){
                console.log(err);
                return ;
            }
            if (!results) {
                return res.json({
                    succes: 0,
                    message: "SCategorie not found"
                })
            }
            return res.json({
                succes: 1,
                data: results
            })
        });
    },
    updateCategoriesMontantAdd: (req,res)=>{
        const body = req.body;
        addMontantToCategorie(body, (err, results) => {
            if(err){
                console.log(err);
                return false;
            }
            if(!results){
                return res.json({
                    succes: 0,
                    message: "Failed to update Categorie Montant ++"
                });
            }
            return res.json({
                succes: 1,
                MESSAGE: "Categorie Montant Updated Succefully ++"
            })
        });
    },
    updateCategoriesMontantRemove: (req,res)=>{
        const body = req.body;
        RemoveMontantFromCategorie(body, (err, results) => {
            if(err){
                console.log(err);
                return false;
            }
            if(!results){
                return res.json({
                    succes: 0,
                    message: "Failed to update Categorie Montant --"
                });
            }
            return res.json({
                succes: 1,
                MESSAGE: "Categorie Montant Updated Succefully --"
            })
        });
    }
};
