const pool =require ("../../config/database");
module.exports = 
{   //CreateReclamation
    createIncom: (data,callBack) => 
    {
                pool.query('insert into incomes (montant, time, date, id_user) values (?,?,?,?)',[
                    data.montant,
                    data.time,
                    data.date,
                    data.id_user
                ],(error,results,fields)=>{
                    if(error){
                        return callBack(error);
                    }
                    return callBack(null,results);
                });
    },
    //GetUserReclamations
    getIncomByUser: (id,callBack) => {
                pool.query(' select id, montant, time, date, id_user from incomes where id_user=?',
                [id],
                (error, results, fields) => {
                    if (error){
                        return callBack(error);
                    }
                    return callBack(null,results);
                });
    },
    //DeleteReclamation
    deleteIncom: (data,callBack) => 
    {
                pool.query('delete from incomes where id=?',
                    [data.id]
                    ,(error,results,fields)=>{
                    if(error){
                        return callBack(error);
                    }
                    return callBack(null,results);
                });
    }
};