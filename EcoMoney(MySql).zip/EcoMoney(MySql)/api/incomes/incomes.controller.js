const {
    createIncom,
    getIncomByUser,
    deleteIncom
      } = require("./incomes.service");


module.exports = {
    createIncomes: (req,res) => {
        const body = req.body;
        createIncom(body,(err, results) => {
            if(err){
                console.log(err);
                return res.status(500).json({
                    succes: 0,
                    message: err
                })
            }
            return res.json({
                success: 1,
                message: "Income added" });
        });
    },
    getIncomes: (req,res)=>{
        const id = req.params.id;
        getIncomByUser(id,(err, results) => {
            if(err){
                console.log(err);
                return;
            }
            return res.json({
                succes: 1,
                data: results
            })
        });
    },
    deleteIncomes: (req,res)=>{
        const data = req.body;
        deleteIncom(data,(err, results) => {
            if(err){
                console.log(err);
                return;
            }
            if(!results){
                return res.json({
                    succeded: 0,
                    message: "Incomes not found"
                })
            }
            return res.json({
                succeded: 1,
                message: "Incomes deleted succefully"
            })
        });
    }

};
