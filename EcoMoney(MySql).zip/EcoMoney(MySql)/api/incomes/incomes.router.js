const{
    createIncomes,
    getIncomes,
    deleteIncomes,
} = require("./incomes.controller");

const router = require("express").Router();
const { checkToken } = require ("../../auth/token_validation");
const { checkAuth } = require("../../auth/authorize")

router.post("/",createIncomes);
router.get("/user/:id",getIncomes);
router.delete("/",deleteIncomes);
module.exports = router;
