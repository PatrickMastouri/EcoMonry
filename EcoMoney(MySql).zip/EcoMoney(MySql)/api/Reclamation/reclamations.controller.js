const {
    createRec,
    getReclamationsByReclamation,
    getReclamation,
    updateReclamation,
    deleteReclamation,
    getAllReclamations
      } = require("./reclamations.service");


module.exports = {
    createReclamation: (req,res) => {
        const body = req.body;
        createRec(body,(err, results) => {
            if(err){
                console.log(err);
                return res.status(500).json({
                    succes: 0,
                    message: err
                })
            }
            return res.json({
                success: 1,
                message: "Reclamation added" });
        });
    },
    getReclamationByReclamationId: (req,res) => {
        const id = req.params.id;
        getReclamationsByReclamation(id, (err,results)=>{
            if (err){
                console.log(err);
                return ;
            }
            if (!results) {
                return res.json({
                    succes: 0,
                    message: "Categorie not found"
                })
            }
            return res.json({
                succes: 1,
                data: results
            })
        });
    },
    getReclamation: (req,res)=>{
        const id = req.params.id;
        getReclamation(id,(err, results) => {
            if(err){
                console.log(err);
                return;
            }
            return res.json({
                succes: 1,
                data: results
            })
        });
    },
    getAllReclamation: (req,res)=>{
        getAllReclamations((err, results) => {
            if(err){
                console.log(err);
                return;
            }
            return res.json({
                succes: 1,
                data: results
            })
        });
    },
    updateReclamation: (req,res)=>{
        const body = req.body;
        updateReclamation(body, (err, results) => {
            if(err){
                console.log(err);
                return false;
            }
            if(!results){
                return res.json({
                    succes: 0,
                    message: "Failed to update Categorie"
                });
            }
            return res.json({
                succes: 1,
                MESSAGE: "Categorie Updated Succefully"
            })
        });
    },
    deleteReclamation: (req,res)=>{
        const data = req.body;
        deleteReclamation(data,(err, results) => {
            if(err){
                console.log(err);
                return;
            }
            if(!results){
                return res.json({
                    succeded: 0,
                    message: "Categorie not found"
                })
            }
            return res.json({
                succeded: 1,
                message: "Categorie deleted succefully"
            })
        });
    }

};
