const pool =require ("../../config/database");
module.exports = 
{   //CreateReclamation
    createRec: (data,callBack) => 
    {
                pool.query('insert into reclamation (subject, message, id_user) values (?,?,?)',[
                    data.subject,
                    data.message,
                    data.id_user
                ],(error,results,fields)=>{
                    if(error){
                        return callBack(error);
                    }
                    return callBack(null,results);
                });
    },
    //GetUserReclamations
    getReclamation: (id,callBack) => {
                pool.query(' select id, subject, message, id_user from reclamation where id_user=?',
                [id],
                (error, results, fields) => {
                    if (error){
                        return callBack(error);
                    }
                    return callBack(null,results);
                });
    },
    //GetAllReclamations
    getAllReclamations: (callBack) => {
        pool.query(' select id, subject, message, id_user from reclamation',
        [],
        (error, results, fields) => {
            if (error){
                return callBack(error);
            }
            return callBack(null,results);
        });
},
    //GetReclamationById
    getReclamationsByReclamation: (id, callBack) => {
        pool.query(' select id, subject, message, id_user from reclamation where id=?',
        [id],
        (error, results, fields) => {
            if (error){
                callBack(error);
            }
            return callBack(null, results[0]);
        });
    },
    //UpdateReclamation
    updateReclamation: (data,callBack) => 
    {
                pool.query('update reclamation set subject=?, message=?, id_user=? where id=?',[
                    data.subject,
                    data.message,
                    data.id_user,
                    data.id
                ],(error,results,fields)=>{
                    if(error){
                        return callBack(error);
                    }
                    return callBack(null,results);
                });
    },
    //DeleteReclamation
    deleteReclamation: (data,callBack) => 
    {
                pool.query('delete from reclamation where id=?',
                    [data.id]
                    ,(error,results,fields)=>{
                    if(error){
                        return callBack(error);
                    }
                    return callBack(null,results);
                });
    }
};