const{
    createReclamation,
    getReclamationByReclamationId,
    getReclamation,
    updateReclamation,
    deleteReclamation,
    getAllReclamation
} = require("./reclamations.controller");

const router = require("express").Router();
const { checkToken } = require ("../../auth/token_validation");
const { checkAuth } = require("../../auth/authorize")

router.post("/",createReclamation);
router.get("/user/:id",getReclamation);
router.get("/",getAllReclamation);
router.get("/:id",getReclamationByReclamationId);
router.patch("/",updateReclamation);
router.delete("/",deleteReclamation);
module.exports = router;
