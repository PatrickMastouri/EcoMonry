const{
    createUser,
    getUserByUserId,
    getUsers,
    updateUsers,
    login,
    deleteUsers,
    confirmations,
    sendPasswordCode,
    passwordChange,
    sendConfirmationUrl,
    getUserByUserMail,
    editExxpenses
} = require("./user.controller");

const router = require("express").Router();
const { checkToken } = require ("../../auth/token_validation");
const { checkAuth } = require("../../auth/authorize")


router.post("/",createUser);
router.get("/",checkToken,getUsers);
router.get("/:id",getUserByUserId);
router.get("/mail/:mail",getUserByUserMail);
router.patch("/",checkToken,updateUsers);
router.delete("/",deleteUsers);
router.post("/login",login);
router.patch("/editexpenses",editExxpenses);
router.post("/sendconfirmationurl",sendConfirmationUrl);      // Yab3eth el mail de Confirmation
router.get("/confirmation/:token/:id",confirmations)         // ki ienzel 3al mail mta3 el confirmation
router.post("/forgetpasswordconfirmation/",sendPasswordCode) // send mail with code for forget password
router.patch("/forgetpasswordchange/",passwordChange)        // bch ybadel el password Lezmou yab3eth el code ely jeh fel mail fel body mouch fel url


module.exports = router;
