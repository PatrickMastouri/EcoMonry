const{
    createCategorie,
    getCategorieByCategorieId,
    getCategories,
    updateCategories,
    deleteCategories,
    getCategorieUsers,
    PriceOfSC
} = require("./categories.controller");

const router = require("express").Router();
const { checkToken } = require ("../../auth/token_validation");
const { checkAuth } = require("../../auth/authorize")

router.post("/",createCategorie);
router.get("/",getCategories);
router.get("/:id",getCategorieByCategorieId);
router.get("/usercat/:id_user",getCategorieUsers);
router.get("/priceofc/:id",PriceOfSC);
router.patch("/",updateCategories);
router.delete("/",deleteCategories);
module.exports = router;
