require("dotenv").config();
const express = require('express');
var app = express();
const userRouter = require("./api/users/user.router");
const categorieRouter = require("./api/categories/categories.router");
const scategorieRouter = require("./api/scategories/scategories.router");
const reclamationRouter = require("./api/Reclamation/reclamations.router");
const incomesRouter = require("./api/incomes/incomes.router");


app.use(express.json());
app.use("/api/users", userRouter);
app.use("/api/categories", categorieRouter);
app.use("/api/scategories", scategorieRouter);
app.use("/api/reclamations", reclamationRouter);
app.use("/api/incomes", incomesRouter);

//Set the listner Port
app.listen(process.env.APP_PORT, ()=>{
    console.log('Server Started On Port', process.env.APP_PORT)
});